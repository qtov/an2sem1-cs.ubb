greater(A, B, true):-
    A > B.
greater(A, B, false):-
    B @>= A.
